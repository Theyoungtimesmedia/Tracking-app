// Sample data for demonstration
let parcels = {
    'ST001234567': {
        id: 'ST001234567',
        sender: 'John Doe',
        senderAddress: '123 Main St, New York, NY 10001',
        recipient: 'Jane Smith',
        recipientAddress: '456 Oak Ave, Los Angeles, CA 90001',
        weight: '2.5 kg',
        service: 'Express Delivery',
        status: 'In Transit',
        timeline: [
            {
                date: '2024-01-15 09:00',
                status: 'Package Picked Up',
                location: 'New York, NY',
                completed: true
            },
            {
                date: '2024-01-15 14:30',
                status: 'Departed Facility',
                location: 'New York Distribution Center',
                completed: true
            },
            {
                date: '2024-01-16 08:15',
                status: 'In Transit',
                location: 'Chicago, IL',
                completed: true
            },
            {
                date: '2024-01-16 18:00',
                status: 'Out for Delivery',
                location: 'Los Angeles, CA',
                completed: false
            },
            {
                date: '2024-01-16 20:00',
                status: 'Delivered',
                location: 'Los Angeles, CA',
                completed: false
            }
        ]
    }
};

// API base for backend (change if backend runs on different host/port)
const API_BASE = window.API_BASE || 'http://127.0.0.1:5000';

// Mobile menu toggle
document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', function(e) {
            e.stopPropagation();
            navMenu.classList.toggle('active');
        });
        // Close menu when clicking outside
        document.body.addEventListener('click', function(e) {
            if (window.innerWidth <= 900 && navMenu.classList.contains('active')) {
                if (!navMenu.contains(e.target) && !hamburger.contains(e.target)) {
                    navMenu.classList.remove('active');
                }
            }
        });
    }
    // Close mobile menu when clicking on a link
    document.querySelectorAll('.nav-menu a').forEach(link => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('active');
        });
    });
});

// Smooth scrolling
function scrollToSection(sectionId) {
    document.getElementById(sectionId).scrollIntoView({
        behavior: 'smooth'
    });
}

// Track parcel function
function trackParcel() {
    const trackingCode = document.getElementById('trackingInput').value.trim().toUpperCase();
    const resultsDiv = document.getElementById('trackingResults');
    const parcelDetailsDiv = document.getElementById('parcelDetails');
    const timelineContainer = document.getElementById('timelineContainer');
    
    if (!trackingCode) {
        showAlert('Please enter a tracking code', 'error');
        return;
    }
    
    if (parcels[trackingCode]) {
        const parcel = parcels[trackingCode];
        
        // Display parcel information
        parcelDetailsDiv.innerHTML = `
            <div class="info-grid">
                <div class="info-item">
                    <strong>Tracking Code:</strong><br>
                    ${parcel.id}
                </div>
                <div class="info-item">
                    <strong>Service Type:</strong><br>
                    ${parcel.service}
                </div>
                <div class="info-item">
                    <strong>Weight:</strong><br>
                    ${parcel.weight}
                </div>
                <div class="info-item">
                    <strong>Current Status:</strong><br>
                    ${parcel.status}
                </div>
                <div class="info-item">
                    <strong>From:</strong><br>
                    ${parcel.sender}<br>
                    ${parcel.senderAddress}
                </div>
                <div class="info-item">
                    <strong>To:</strong><br>
                    ${parcel.recipient}<br>
                    ${parcel.recipientAddress}
                </div>
            </div>
        `;
        
        // Display timeline
        let timelineHTML = '<div class="timeline">';
        parcel.timeline.forEach(item => {
            timelineHTML += `
                <div class="timeline-item ${item.completed ? 'completed' : ''}">
                    <div class="timeline-date">${formatDate(item.date)}</div>
                    <div class="timeline-status">${item.status}</div>
                    <div class="timeline-location">${item.location}</div>
                </div>
            `;
        });
        timelineHTML += '</div>';
        timelineContainer.innerHTML = timelineHTML;
        resultsDiv.style.display = 'block';
    } else {
        // Not found in local demo data — attempt to fetch from backend
        parcelDetailsDiv.innerHTML = '';
        timelineContainer.innerHTML = '';
        resultsDiv.style.display = 'none';

        // show a simple loading indicator
        const loading = document.createElement('div');
        loading.id = 'tracking-loading';
        loading.textContent = 'Looking up tracking code...';
        resultsDiv.parentElement.appendChild(loading);

        fetch(`${API_BASE}/api/parcels/${encodeURIComponent(trackingCode)}`)
            .then(async (response) => {
                if (!response.ok) {
                    if (response.status === 404) throw new Error('Tracking code not found');
                    const text = await response.text();
                    throw new Error(text || `Server error (${response.status})`);
                }
                return response.json();
            })
            .then(parcel => {
                // normalize parcel fields to match demo view
                const normalized = {
                    id: parcel.trackingCode || parcel.id || trackingCode,
                    sender: parcel.senderName || parcel.sender || '',
                    senderAddress: parcel.senderAddress || parcel.senderAddress || '',
                    recipient: parcel.recipientName || parcel.recipient || '',
                    recipientAddress: parcel.recipientAddress || parcel.recipientAddress || '',
                    weight: parcel.weightKg ? `${parcel.weightKg} kg` : (parcel.weight || ''),
                    service: parcel.serviceType || parcel.service || '',
                    status: parcel.status || '',
                    timeline: (parcel.timeline || []).map(t => ({ date: t.date || t, status: t.status || '', location: t.location || '', completed: !!t.completed }))
                };

                // render the same UI as local demo
                parcelDetailsDiv.innerHTML = `
                    <div class="info-grid">
                        <div class="info-item">
                            <strong>Tracking Code:</strong><br>
                            ${normalized.id}
                        </div>
                        <div class="info-item">
                            <strong>Service Type:</strong><br>
                            ${normalized.service}
                        </div>
                        <div class="info-item">
                            <strong>Weight:</strong><br>
                            ${normalized.weight}
                        </div>
                        <div class="info-item">
                            <strong>Current Status:</strong><br>
                            ${normalized.status}
                        </div>
                        <div class="info-item">
                            <strong>From:</strong><br>
                            ${normalized.sender}<br>
                            ${normalized.senderAddress}
                        </div>
                        <div class="info-item">
                            <strong>To:</strong><br>
                            ${normalized.recipient}<br>
                            ${normalized.recipientAddress}
                        </div>
                    </div>
                `;

                let timelineHTML = '<div class="timeline">';
                normalized.timeline.forEach(item => {
                    timelineHTML += `
                        <div class="timeline-item ${item.completed ? 'completed' : ''}">
                            <div class="timeline-date">${formatDate(item.date)}</div>
                            <div class="timeline-status">${item.status}</div>
                            <div class="timeline-location">${item.location}</div>
                        </div>
                    `;
                });
                timelineHTML += '</div>';
                timelineContainer.innerHTML = timelineHTML;
                resultsDiv.style.display = 'block';
            })
            .catch(err => {
                showAlert(err.message || 'Error looking up tracking code', 'error');
            })
            .finally(() => {
                const l = document.getElementById('tracking-loading');
                if (l && l.parentElement) l.parentElement.removeChild(l);
            });
    }
}

// Helper: show alert message
function showAlert(message, type) {
    alert(message); // Simple fallback, replace with custom UI if needed
}

// Helper: format date string
function formatDate(dateStr) {
    // Example: '2024-01-15 09:00' => 'Jan 15, 2024 09:00'
    const d = new Date(dateStr.replace(/-/g, '/'));
    if (isNaN(d)) return dateStr;
    const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
    return d.toLocaleString(undefined, options);
}