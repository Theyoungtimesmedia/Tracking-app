// Handles toggling the live chat widget
function toggleChat() {
    const chatWidget = document.getElementById('chatWidget');
    const chatBody = document.getElementById('chatBody');
    const chatToggle = document.getElementById('chatToggle');
    if (chatBody.style.display === 'none' || chatBody.classList.contains('collapsed')) {
        chatBody.style.display = 'block';
        chatBody.classList.remove('collapsed');
        chatToggle.classList.remove('fa-chevron-down');
        chatToggle.classList.add('fa-chevron-up');
    } else {
        chatBody.style.display = 'none';
        chatBody.classList.add('collapsed');
        chatToggle.classList.remove('fa-chevron-up');
        chatToggle.classList.add('fa-chevron-down');
    }
}

// Hide chat on load, show only when header is clicked
window.addEventListener('DOMContentLoaded', function() {
    const chatBody = document.getElementById('chatBody');
    const chatToggle = document.getElementById('chatToggle');
    if (chatBody) {
        chatBody.style.display = 'none';
        chatBody.classList.add('collapsed'); 
    }
    if (chatToggle) {
        chatToggle.classList.remove('fa-chevron-up');
        chatToggle.classList.add('fa-chevron-down');
    }
});

// Dummy sendMessage and handleChatKeyPress for completeness
function sendMessage() {}
function handleChatKeyPress(e) {}
