const Contact = require('../models/Contact');
const InMemory = require('../lib/inMemoryStore');

const store = process.env.USE_IN_MEMORY_DB === 'true' ? InMemory : null;
console.log(`[contactController] USE_IN_MEMORY_DB=${process.env.USE_IN_MEMORY_DB}; store=${store ? 'in-memory' : 'mongo'}`);

exports.submitContact = async (req, res) => {
  try {
    console.log('[contactController] submitContact body=', req.body);
    const { name, email, subject, message } = req.body;
    if (!name || !email || !message) return res.status(400).json({ message: 'Missing required fields' });

    if (store) {
      const c = { id: Date.now().toString(), name, email, subject, message, createdAt: new Date() };
      await store.createContact(c);
      return res.status(201).json({ message: 'Received', contact: c });
    }

    const contact = new Contact({ name, email, subject, message });
    await contact.save();
    return res.status(201).json({ message: 'Received', contact });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
};
