const Parcel = require('../models/Parcel');
const InMemory = require('../lib/inMemoryStore');

const store = process.env.USE_IN_MEMORY_DB === 'true' ? InMemory : null;
console.log(`[parcelController] USE_IN_MEMORY_DB=${process.env.USE_IN_MEMORY_DB}; store=${store ? 'in-memory' : 'mongo'}`);

// Generate a simple tracking code
function generateTrackingCode() {
  return 'ST' + Math.random().toString(36).substr(2, 9).toUpperCase();
}

exports.createParcel = async (req, res) => {
  try {
    console.log('[parcelController] createParcel body=', req.body);
    const { senderName, senderAddress, recipientName, recipientAddress, weightKg, serviceType } = req.body;
    if (!senderName || !senderAddress || !recipientName || !recipientAddress || !weightKg || !serviceType) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    const trackingCode = generateTrackingCode();
    const initialTimeline = [{ date: new Date(), status: 'Package Picked Up', location: '', completed: true }];

    if (store) {
      const parcel = { trackingCode, senderName, senderAddress, recipientName, recipientAddress, weightKg, serviceType, status: 'Package Picked Up', timeline: initialTimeline };
      await store.createParcel(parcel);
      return res.status(201).json(parcel);
    }

    const parcel = new Parcel({ trackingCode, senderName, senderAddress, recipientName, recipientAddress, weightKg, serviceType, timeline: initialTimeline, status: 'Package Picked Up' });
    await parcel.save();
    return res.status(201).json(parcel);
  } catch (err) {
    console.error('[parcelController] error:', err && err.stack ? err.stack : err);
    return res.status(500).json({ message: 'Server error' });
  }
};

exports.getParcelByCode = async (req, res) => {
  try {
    const code = (req.params.code || '').toUpperCase();
    console.log('[parcelController] getParcelByCode code=', code);
    if (!code) return res.status(400).json({ message: 'Tracking code required' });

    if (store) {
      const p = await store.getParcel(code);
      if (!p) return res.status(404).json({ message: 'Not found' });
      return res.json(p);
    }

    const parcel = await Parcel.findOne({ trackingCode: code }).lean();
    if (!parcel) return res.status(404).json({ message: 'Not found' });
    return res.json(parcel);
  } catch (err) {
    console.error('[parcelController] error:', err && err.stack ? err.stack : err);
    return res.status(500).json({ message: 'Server error' });
  }
};
