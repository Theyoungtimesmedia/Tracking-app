const express = require('express');
const router = express.Router();
const parcelController = require('../controllers/parcelController');

router.post('/', parcelController.createParcel);
router.get('/:code', parcelController.getParcelByCode);

module.exports = router;
