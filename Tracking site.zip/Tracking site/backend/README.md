# Parcel Tracking Backend

This is the backend API for the Parcel Tracking website, built with Node.js, Express, and MongoDB.

## Features
- Parcel management API
- User authentication (to be added)
- Contact form endpoint (to be added)
- MongoDB integration

## Setup
1. Install dependencies:
   ```
   npm install
   ```
2. Add your MongoDB connection string to `.env`:
   ```
   MONGO_URI=your_mongodb_connection_string_here
   ```
3. Start the server:
   ```
   npm run dev
   ```

## Folder Structure
- `server.js` - Main entry point
- `routes/` - API route files
- `controllers/` - Route logic
- `models/` - Mongoose schemas
- `config/` - Database config

## Next Steps
- Add routes, controllers, and models for parcels, users, and contact form
- Implement authentication
- Connect frontend to backend API
