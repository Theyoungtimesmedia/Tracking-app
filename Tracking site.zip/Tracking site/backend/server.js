require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Connect to MongoDB (or set in-memory fallback)
const connectDB = require('./config/db');

// Ensure DB connection attempt happens before loading route handlers
// so controllers can see process.env.USE_IN_MEMORY_DB when they initialize.
(async () => {
  await connectDB();

  // Import routes after DB connection decision
  const parcelRoutes = require('./routes/parcelRoutes');
  const contactRoutes = require('./routes/contactRoutes');
  app.use('/api/parcels', parcelRoutes);
  app.use('/api/contact', contactRoutes);

  // Basic health endpoint
  app.get('/health', (req, res) => res.json({ status: 'ok' }));

  app.get('/', (req, res) => {
    res.send('Parcel Tracking Backend API');
  });

  const PORT = process.env.PORT || 5000;
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
})();

// Simple error handler
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ message: 'Internal server error' });
});
