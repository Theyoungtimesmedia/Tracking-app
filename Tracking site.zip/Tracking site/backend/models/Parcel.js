const mongoose = require('mongoose');

const TimelineSchema = new mongoose.Schema({
  date: { type: Date, required: true },
  status: { type: String, required: true },
  location: { type: String },
  completed: { type: Boolean, default: false },
});

const ParcelSchema = new mongoose.Schema({
  trackingCode: { type: String, required: true, unique: true },
  senderName: { type: String, required: true },
  senderAddress: { type: String, required: true },
  recipientName: { type: String, required: true },
  recipientAddress: { type: String, required: true },
  weightKg: { type: Number, required: true },
  serviceType: { type: String, required: true },
  status: { type: String, default: 'Package Picked Up' },
  timeline: { type: [TimelineSchema], default: [] },
}, { timestamps: true });

module.exports = mongoose.models.Parcel || mongoose.model('Parcel', ParcelSchema);
