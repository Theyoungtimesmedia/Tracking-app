const mongoose = require('mongoose');

/**
 * Attempts to connect to MongoDB. If MONGO_URI is not set or left as the
 * placeholder value, the function will skip connecting and set
 * process.env.USE_IN_MEMORY_DB = 'true' so the app can run without MongoDB.
 */
const connectDB = async () => {
  const uri = process.env.MONGO_URI;
  if (!uri || uri === 'your_mongodb_connection_string_here') {
    console.warn('MONGO_URI not provided or left as placeholder. Using in-memory fallback.');
    process.env.USE_IN_MEMORY_DB = 'true';
    return;
  }

  try {
    await mongoose.connect(uri, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('MongoDB connected');
  } catch (error) {
    console.error('MongoDB connection error:', error.message);
    console.warn('Falling back to in-memory DB. Set a valid MONGO_URI to use MongoDB.');
    process.env.USE_IN_MEMORY_DB = 'true';
  }
};

module.exports = connectDB;
